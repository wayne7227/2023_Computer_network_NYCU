#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

struct consumers_infos {
  string consumer;
  string interest_per_second;
  string app_duration_time;
  string prefix;
};
typedef struct consumers_infos consumers_infos;

struct producers_infos {
  string producer;
  string prefix;
};
typedef struct producers_infos producers_infos;

struct links_infos {
  int from_node;
  int to_node;
};

struct links_infos {
  int from_node;
  int to_node;
};
typedef struct links_infos links_infos;

namespace ns3 {

int main(int argc, char *argv[]) {
  // config parameters
  int nums_nodes, nums_lines, nums_consumers, nums_producers;
  vector<links_infos> line_rec;
  vector<consumers_infos> consumers_rec;
  vector<producers_infos> producers_rec;

  // read the input
  cout << "Input your topology config : ";
  string path;
  getline(cin, path);
  path = "/app/Lab1_Checker/scenario/" + path;
  cout << path << endl;
  ifstream in(path);
  if (!in.is_open()) {
    cout << "Can not read input file ..." << endl;
    return 1; // error num
  }

  // config the requirements
  in >> nums_nodes >> nums_lines >> nums_consumers >> nums_producers;

  // config the lines
  for (int i = 0; i < nums_lines; i++) {
    links_infos l_info;
    in >> l_info.from_node >> l_info.to_node;
    line_rec.push_back(l_info);
  }

   
 // config the consumers
  for (int i = 0; i < nums_consumers; i++) {
    consumers_infos c_info;
    in >> c_info.consumer >> c_info.interest_per_second >> c_info.app_duration_time >> c_info.prefix;
    consumers_rec.push_back(c_info);
  }

  // config the producers
  for (int i = 0; i < nums_producers; i++) {
    producers_infos p_info;
    in >> p_info.producer >> p_info.prefix;
    producers_rec.push_back(p_info);
  }

  // setting default parameters for PointToPoint links and channels
  Config::SetDefault("ns3::PointToPointNetDevice::DataRate", StringValue("1Mbps"));
  Config::SetDefault("ns3::PointToPointChannel::Delay", StringValue("10ms"));
  Config::SetDefault("ns3::QueueBase::MaxSize", StringValue("20p"));

  // Creating nodes
  NodeContainer nodes;
  nodes.Create(nums_nodes);
  cout << nums_nodes << endl;
  // Connecting nodes using two links
  PointToPointHelper p2p;
  for (int i = 0; i < nums_lines; i++) {
    p2p.Install(nodes.Get(line_rec[i].from_node), nodes.Get(line_rec[i].to_node));
  }

  // Install NDN stack on all nodes

ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes(true);
  ndnHelper.InstallAll();

  // Choosing forwarding strategy
  ndn::StrategyChoiceHelper::InstallAll("/", "/localhost/nfd/strategy/multicast");

   // Consumer
  ndn::AppHelper consumerHelper("ns3::ndn::ConsumerCbr");
  // Consumer will request /prefix/0, /prefix/1, ...
  consumerHelper.SetPrefix("/prefix");
  consumerHelper.SetAttribute("Frequency", StringValue("10")); // 10 interests a second
  auto apps = consumerHelper.Install(nodes.Get(2));                        // first node
  apps.Stop(Seconds(10.0)); // stop the consumer app at 10 seconds mark

  ndn::AppHelper producerHelper("ns3::ndn::Producer");
  // Producer will reply to all requests starting with /prefix
  producerHelper.SetPrefix("/prefix");
  producerHelper.SetAttribute("PayloadSize", StringValue("1024"));
  producerHelper.Install(nodes.Get(1)); // last node
  // Producer



  Simulator::Stop(Seconds(20.0));
  Simulator::Run();
  Simulator::Destroy();

  return 0;
}

} // namespace ns3

int main(int argc, char *argv[]) {
  return ns3::main(argc, argv);
}